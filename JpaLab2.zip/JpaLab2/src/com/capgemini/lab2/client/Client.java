/**
 * 
 */
package com.capgemini.lab2.client;

import java.util.List;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.lab2.dao.Lab2Dao;
import com.capgemini.lab2.dao.Lab2DaoImpl;
import com.capgemini.lab2.entities.Author;
import com.capgemini.lab2.entities.Book;

/**
 * @author mayur shinde
 *
 */
public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Lab2Dao dao = new Lab2DaoImpl();
		Scanner scan = new Scanner(System.in);
		
		Author author1 = new Author("Robin Sharma", 100);
		Author author2 = new Author("Dan Brown", 200);

		Book book1 = new Book(214521445, "The Monk Who Sold The ferrari", 200);
		Book book4 = new Book(141314114, "The 5am Club", 200);
		Book book2 = new Book(134611311, "Inferno", 400);
		Book book3 = new Book(161441334, "Angel and Demons", 600);

		author1.addBooks(book1);
		author1.addBooks(book4);
		author2.addBooks(book2);
		author2.addBooks(book3);
		em.getTransaction().begin();
		em.persist(author1);
		em.persist(author2);

		List<Book> b = dao.fetchAllBooks();
		for (Book book : b) {
			System.out.println(book);
		}
		System.out.println("Enter Author name:");
		String authorName = scan.nextLine();
		Set<Book> book = dao.fetchBooksByAuthorName(authorName);
		
		for (Book b1 : book) {
			System.out.println(b1);
			
		}
		System.out.println("Enter ISBN Number of the book to be found:");
		long bookId = scan.nextLong();
		Set<Author> bookByAuthor = dao.fetchAuthorsByBookId(bookId);
		for (Author b2 : bookByAuthor) {
			System.out.println(b2);
			
		}
		
		List<Book> bookByPriceRange = dao.getBooksByPriceRange();
		for (Book book5 : bookByPriceRange) {
			System.out.println(book5);
		}

		 //em.getTransaction().commit();

	}

}
