/**
 * 
 */
package com.capgemini.lab2.service;

/**
 * @author mayur shinde
 *
 */
public class Lab2SeriveImpl {

}
