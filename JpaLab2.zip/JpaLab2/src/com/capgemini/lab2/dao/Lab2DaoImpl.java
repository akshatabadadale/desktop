/**
 * 
 */
package com.capgemini.lab2.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.lab2.entities.Author;
import com.capgemini.lab2.entities.Book;

/**
 * @author mayur shinde
 *
 */
public class Lab2DaoImpl implements Lab2Dao {
	EntityManager em;
	

	public Lab2DaoImpl() {
		em = JPAUtil.getEntityManager();
	}

	@Override
	public List<Book> fetchAllBooks( ) {
		
		String qStr = "SELECT book FROM Book book";
//		TypedQuery<String>query = em.createQuery(qStr, Book.class);
		List<Book> book = em.createQuery(qStr).getResultList();
		
		return book;
	}
	
	public Set fetchBooksByAuthorName(String authorName) {

		Author author= em.createQuery("SELECT author from Author author WHERE author.authorName=:authorName", Author.class).setParameter("authorName", authorName).getSingleResult();
		Set bookList=  author.getBooks();

	
		return bookList;
	}
		public List getBooksByPriceRange() {
		List bookList= em.createQuery("SELECT book from Book book WHERE book.price between 500 and 1000", Book.class).getResultList();
		return bookList;
	}
	
	public Set fetchAuthorsByBookId(long bookId) {
		 
		Book book=em.createQuery("SELECT book from Book book WHERE book.ISBN=:bookId", Book.class).setParameter("bookId", bookId).getSingleResult();		
		Set authorList= book.getAuthors();
		
		return authorList;
	}

}
