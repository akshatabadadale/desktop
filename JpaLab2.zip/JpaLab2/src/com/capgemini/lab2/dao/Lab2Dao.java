/**
 * 
 */
package com.capgemini.lab2.dao;

import java.util.List;
import java.util.Set;

import com.capgemini.lab2.entities.Author;
import com.capgemini.lab2.entities.Book;

/**
 * @author mayur shinde
 * 
 *
 */
public interface Lab2Dao {
	public List<Book> fetchAllBooks();

	public Set fetchBooksByAuthorName(String authorName);

	public Set fetchAuthorsByBookId(long bookId);

	public List getBooksByPriceRange();

}
