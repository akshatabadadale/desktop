/**
 * 
 */
package com.capgemini.lab2.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * @author mayur shinde
 *
 */
@Entity
@Table(name="book_table")
public class Book {
	
	@Id	
	private long ISBN;
	private String title;
	private int price;
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="books")
	 Set<Author> authors = new HashSet<Author>();

	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price
				+"]";
	}

	public long getISBN() {
		return ISBN;
	}

	public void setISBN(long iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Set<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}

	public Book(long iSBN, String title, int price) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
	}

	public Book() {
	}
	

}
