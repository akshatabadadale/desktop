/**
 * 
 */
package com.capgemini.lab2.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;



/**
 * @author mayur shinde
 *
 */
@Entity
@Table(name="author_table")
public class Author {
	private String authorName;
	@Id
	
	private int authorId;
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "book_author", joinColumns = { @JoinColumn(name = "authorId") },
	inverseJoinColumns = { @JoinColumn(name = "ISBN") })
	 Set<Book> books = new HashSet<Book>();

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	public Author(String authorName, int authorId) {
		super();
		this.authorName = authorName;
		this.authorId = authorId;
	}

	public Author() {
	}
	
	public void addBooks(Book book) {
		this.getBooks().add(book);
	}

	@Override
	public String toString() {
		return "Author [authorName=" + authorName + ", authorId=" + authorId
				+"]";
	}

}
