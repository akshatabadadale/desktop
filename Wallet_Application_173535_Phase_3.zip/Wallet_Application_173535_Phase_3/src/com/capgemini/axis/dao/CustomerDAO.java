package com.capgemini.axis.dao;

import java.util.List;

import com.capgemini.axis.bean.Customer;
import com.capgemini.axis.bean.Transaction;
import com.capgemini.axis.exception.CustomerExists;
import com.capgemini.axis.exception.CustomerNotFoundException;
import com.capgemini.axis.exception.InsufficientBalanceException;

public interface CustomerDAO {

	Customer createCustomer(Customer customer) throws CustomerExists;

	String withdraw(Customer customer, double amount)	throws InsufficientBalanceException;

	String deposit(Customer customer, double amount) throws CustomerNotFoundException;

	Customer checkUser(String username, String password) throws CustomerNotFoundException;

	List<Transaction> printTransaction(Customer customer);

	Customer isValidUser(String mobileNumber) throws CustomerNotFoundException;
	
	double checkBalance(Customer customer);

	void beginTransaction();
	void commitTransaction();
}
