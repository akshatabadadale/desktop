package com.capgemini.axis.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="transactions")
public class Transaction {


	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "tid")
	@SequenceGenerator(sequenceName="tid_seq", name = "tid")
	private int tid;
	private String mobileNo;
	private String type;
	private double amount, balance;
	
	public Transaction() {
		super();
	}

	public Transaction(String mobileNo, String type, double amount,
			double balance) {
		this.mobileNo = mobileNo;
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}

	// getters setters
	public String getMobileNo() {
		return mobileNo;
	}

	public String getType() {
		return type;
	}

	public double getAmount() {
		return amount;
	}

	public double getBalance() {
		return balance;
	}

	@Override
	public String toString() {
		return "Transaction [tid=" + tid + ", mobileNo=" + mobileNo
				+ ", type=" + type + ", amount=" + amount + ", balance="
				+ balance + "]\n";
	}

	
}
