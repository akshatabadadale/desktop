/**
 * 
 */

msg = "<h2>This Embedded head script tag "