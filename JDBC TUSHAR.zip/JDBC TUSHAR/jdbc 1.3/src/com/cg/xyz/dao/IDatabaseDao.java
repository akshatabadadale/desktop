package com.cg.xyz.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.xyz.bean.Author;
import com.cg.xyz.bean.Book;

public interface IDatabaseDao {
	void insertIntodatabase(Author auth,Book book) throws SQLException;
	
	//void delete(int authId) throws SQLException;
	
	void update(double price,int isbn) throws SQLException;
	
	List<Author> getAuthor() throws SQLException;
	
	List<Book> getBook(int authid) throws SQLException;
}
