package com.cg.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.xyz.bean.Author;
import com.cg.xyz.bean.Book;
import com.cg.xyz.config.JdbcConfig;

public class DatabaseDao implements IDatabaseDao {
	PreparedStatement statement = null;
	Connection connection;
	ResultSet rs = null;

	public DatabaseDao() {
		try {
			connection = JdbcConfig.getConnection();
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	}

	public void insertIntodatabase(Author auth, Book book) throws SQLException {
		statement = connection.prepareStatement(Querrymapper.insertAuthor);
		statement.setString(1, auth.getFirstname());
		statement.setString(2, auth.getMiddleName());
		statement.setString(3, auth.getLastName());
		statement.setLong(4, auth.getMobile());
		statement.executeUpdate();
		statement = connection.prepareStatement(Querrymapper.insertBook);
		statement.setString(1, book.getTitle());
		statement.setDouble(2, book.getPrice());
		statement.executeUpdate();

		inserttoref(0);
	}

	public void inserttoref(int authId) throws SQLException {
		int bookid = 0;
		ResultSet rs;
		if (authId == 0) {
			statement = connection.prepareStatement(Querrymapper.authid);
			rs = statement.executeQuery();
			if (rs.next())
				authId = rs.getInt(1);
		}
		statement = connection.prepareStatement(Querrymapper.bookid);
		rs = statement.executeQuery();
		if (rs.next())
			bookid = rs.getInt(1);
		statement = connection.prepareStatement(Querrymapper.insertRef);
		statement.setInt(1, bookid);
		statement.setInt(2, authId);
		statement.executeUpdate();
	}

	public void insertIntobook(int authId, Book book) throws SQLException {
		statement = connection.prepareStatement(Querrymapper.insertBook);
		statement.setString(1, book.getTitle());
		statement.setDouble(2, book.getPrice());
		statement.executeUpdate();
		inserttoref(authId);

	}

	@Override
	public void update(double price, int isbn) throws SQLException {
		statement = connection.prepareStatement(Querrymapper.update);
		statement.setDouble(1, price);
		statement.setInt(2, isbn);
		statement.executeUpdate();
		System.out.println("Price Updated");
	}

	@Override
	public List<Author> getAuthor() throws SQLException {
		List<Author> list = new ArrayList<Author>();
		statement = connection.prepareStatement(Querrymapper.getAuthor);
		rs = statement.executeQuery();
		while (rs.next()) {
			list.add(new Author(rs.getInt(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getLong(5)));
		}

		return list;
	}

	@Override
	public List<Book> getBook(int authid) throws SQLException {
		List<Book> list = new ArrayList<Book>();
		statement = connection.prepareStatement(Querrymapper.getBook);
		statement.setInt(1, authid);
		rs = statement.executeQuery();
		while (rs.next()) {
			list.add(new Book(rs.getInt(1), rs.getString(2), rs.getDouble(3)));
		}
		return list;
	}
}