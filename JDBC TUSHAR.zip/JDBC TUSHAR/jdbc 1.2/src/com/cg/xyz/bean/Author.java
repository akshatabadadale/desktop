package com.cg.xyz.bean;

public class Author {
	private int authId;
	private String firstname;
	private String middleName;
	private String lastName;
	private long mobile;

	public Author(String firstname, String middleName, String lastName,
			long mobile) {
		this.firstname = firstname;
		this.middleName = middleName;
		this.lastName = lastName;
		this.mobile = mobile;
	}
	public Author(int authid,String firstname, String middleName, String lastName,
			long mobile) {
		this.authId=authid;
		this.firstname = firstname;
		this.middleName = middleName;
		this.lastName = lastName;
		this.mobile = mobile;
	}
	public Author() {
	}

	public int getAuthId() {
		return authId;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public void setAuthId(int authId) {
		this.authId = authId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "authId=" + authId + ", firstname=" + firstname
				+ ", middleName=" + middleName + ", lastName=" + lastName;
	}

}
