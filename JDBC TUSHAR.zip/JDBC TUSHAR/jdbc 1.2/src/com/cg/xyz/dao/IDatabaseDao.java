package com.cg.xyz.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.xyz.bean.Author;

public interface IDatabaseDao {
	void insertIntodatabase(Author auth) throws SQLException;
		
	void update(long mob,int authid) throws SQLException;
	
	void  delete(int id) throws SQLException;

}
