package com.cg.xyz.dao;

public interface Querrymapper {
	String insertAuthor ="insert into author values(seq_author.nextval,?,?,?,?)";
	String update = "update author set phoneno=? where AUTHORID=?";
	String delete = " delete from author where AUTHORID=?";
}
