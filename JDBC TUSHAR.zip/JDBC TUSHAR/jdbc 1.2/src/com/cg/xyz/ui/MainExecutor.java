/*create table author (authorId number primary key,firstName varchar2(20),middleName varchar2(20),lastName varchar2(20),phoneNo number);
create sequence seq_author
  minvalue 1
  start with 1
 increment by 1
  cache 10;

 */

package com.cg.xyz.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.xyz.bean.Author;
import com.cg.xyz.dao.DatabaseDao;

public class MainExecutor {
	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		int ch = 0;
		String fname;
		String mName;
		String lName;
		long mob;
		String title;
		Double price;
		int authId;
		
		System.out.println("connecting....");
		DatabaseDao dao = new DatabaseDao();
		System.out.println("connected..");

		System.out
				.println("1. Enter Author details\n2. Delete Authors \n3. Update author Mobile no\n4. Exit");
		
		ch = sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("enter Author First name");
			fname = sc.next();
			System.out.println("enter Author middle Name");
			mName = sc.next();
			System.out.println("enter Author last name");
			lName = sc.next();
			System.out.println("enter Phone no");
			mob = sc.nextLong();
			Author auth = new Author(fname, mName, lName, mob);
			dao.insertIntodatabase(auth);
			break;
		case 2:
			System.out.println("enter author Id");
			authId = sc.nextInt();
			dao.delete(authId);
			break;
		case 3:
			System.out.println("enter author Id");
			authId = sc.nextInt();
			System.out.println("enter Mobile no");
			mob = sc.nextLong();
			dao.update(mob, authId);
			break;
		case 4:
			System.exit(0);
		default:

			break;
		}

	}

}
