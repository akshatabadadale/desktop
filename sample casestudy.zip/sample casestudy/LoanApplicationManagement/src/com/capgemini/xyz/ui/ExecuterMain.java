package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.InsertIntoTable;
import com.capgemini.xyz.jdbcutil.JdbcUtil;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.service.ValidateUserInput;

public class ExecuterMain {
	public static void main(String[] args) {
		
		JdbcUtil.getConnection();
		System.out.println("Connection Established");
		Scanner sc = new Scanner(System.in);
		// for validation methods call and Customer Details
		ValidateUserInput userInput = new ValidateUserInput();

		// for applyLoan and viewDetails methods
		LoanService loansvc = new LoanService();
		String loanAmount;
		String loanDuration;
		Loan loan = new Loan();// Loan object
		System.out.println("Mayuresh Finance Company Welcome you");
		System.out.println("1.	Register Customer\n2.	Exit");
		int ch = sc.nextInt();
		long CustID;
		String name;
		String address;
		String email;
		String mobile;
		boolean isValid;
		if (ch == 1) {

			while (true) {

				System.out.println("Enter name");
				name = sc.next();

				// to validate UserName
				isValid = userInput.validateUserName(name);
				if (isValid)
					break; // if user enter valid input then break
				else
					System.out
							.println("Please enter Valid Name.\nName should have minimum 1 or max 10 character \nFirst letter must be capital");
			}
			while (true) {

				System.out.println("Enter address");
				address = sc.next();
				// to Validate User Address
				isValid = userInput.validateAddress(address);
				if (isValid)
					break;// if user enter valid input then break
				else
					System.out
							.println("Please enter Valid Address(eg. Mumbai)");
			}
			while (true) {

				System.out.println("Enter Email");
				email = sc.next();
				// to Validate User Email

				isValid = userInput.validateEmail(email);
				if (isValid)
					break;// if user enter valid input then break
				else
					System.out
							.println("Please enter Valid Email(eg abc@gmail.com)");
			}
			while (true) {

				System.out.println("Enter mobile");
				mobile = sc.next();
				// to validate user Mobile No
				isValid = userInput.validateMobile(mobile);
				if (isValid)
					break;// if user enter valid input then break
				else
					System.out
							.println("Please enter Valid Mobile without +91 (eg. 9167968584)");
			}
			Customer customer = new Customer();// Customer Object
			// setting Customers details
			customer.setCustName(name);
			customer.setAddress(address);
			customer.setMobile(Long.parseLong(mobile));
			customer.setEmail(email);
			userInput.StoreIntoMap(customer);
			
			//jdbc implementation
			InsertIntoTable insert= new InsertIntoTable();
			insert.insertCustomer(customer);
			
			// to save Customer details in Map
			CustID = customer.getCustId(); // get CustId for Set in loan object
			System.out.println("Do you wish to apply for Loan? (Yes/No)");
			String loanCh = sc.next();
			if (loanCh.equalsIgnoreCase("YES")) {
				while (true) {
					System.out.println("Enter the loan amount");
					loanAmount = sc.next();
					isValid = userInput.validateLoanAmount(loanAmount);
					if (isValid)
						break;// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Loan Amount (eg. 400000)");
				}
				while(true){
					System.out.println("Enter the loan duration in years");
					loanDuration = sc.next();
					isValid = userInput.validateLoanAmount(loanDuration);
					if (isValid)
						break;// if user enter valid input then break
					else
						System.out
								.println("Please enter Valid Loan Duration in years(eg. 5)");
				}
				// set loan details
				loan.setLoanAmount(Double.parseDouble(loanAmount));
				loan.setDuration(Integer.parseInt(loanDuration));
				loan.setCustId(CustID);
				loansvc.applyLoan(loan);// Apply for loan
				System.out.println(userInput.displayCustomers());
				System.out.println(loansvc.displayLoan());
				System.out.println(name + " your EMI is : "
						+ loansvc.calculateEMI(Double.parseDouble(loanAmount), Integer.parseInt(loanDuration) * 12));
			} else
				System.out.println(userInput.displayCustomers());
		} else if (ch == 2)
			System.exit(0);
		else
			System.out.println("Please enter Valid Choice");
	}
}
