package com.capgemini.xyz.dao;


public interface QueryMapper {
	String insertDetails = "insert into dcrcustomer"+"(custId,custName,mobile,email)"+"values"+"(?,?,?,?)";
	
	
	//String select=�select * Form customer where cust_id=?�
}

