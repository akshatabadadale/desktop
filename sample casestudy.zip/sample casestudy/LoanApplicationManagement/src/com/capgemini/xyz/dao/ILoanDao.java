package com.capgemini.xyz.dao;

import java.util.ArrayList;


import com.capgemini.xyz.bean.Loan;

public interface ILoanDao {
	//Creating Methods
	 void applyLoan (Loan loan);
	 ArrayList<Loan> displayLoan();
}
