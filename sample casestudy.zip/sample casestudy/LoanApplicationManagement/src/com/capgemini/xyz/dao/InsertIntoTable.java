package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.jdbcutil.JdbcUtil;

public class InsertIntoTable {
	
	Connection connection = null;  //object of connection class
	PreparedStatement statement = null;


	public void insertCustomer(Customer customer){
	connection = JdbcUtil.getConnection(); 
	try {
	statement = connection.prepareStatement(QueryMapper.insertDetails);
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	try {
	statement.setLong(1, customer.getCustId());
	statement.setString(2,customer.getCustName());
	statement.setLong(3, customer.getMobile());
	statement.setString(4,customer.getEmail());
	statement.executeUpdate();
	} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}
	}


