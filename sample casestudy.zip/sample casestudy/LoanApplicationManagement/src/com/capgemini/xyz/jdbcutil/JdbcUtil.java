package com.capgemini.xyz.jdbcutil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class JdbcUtil {
	private static Connection connection = null;  //object for connection

	public static Connection getConnection()   {  //method for connection //kept static

		File file = null;
		FileInputStream inputStream = null;       //input stream to read from the file

		file = new File("resources/jdbc.properties");//new file created named resources having properties
		try {
			inputStream = new FileInputStream(file);

			Properties properties = new Properties();
			properties.load(inputStream);

			String driver = properties.getProperty("db.driver");
			String url = properties.getProperty("db.url");
			String username = properties.getProperty("db.username");
			String password = properties.getProperty("db.password");

			//Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);
				System.out.println("connection established");

	
		}
		catch (Exception e){
			}
		return connection;
		}
	

}
