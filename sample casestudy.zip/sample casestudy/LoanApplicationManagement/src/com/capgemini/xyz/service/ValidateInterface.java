package com.capgemini.xyz.service;

import java.util.ArrayList;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;

public interface ValidateInterface {
	//Matches pattern string 
	String USER_NAME_PATTERN = "[a-zA-Z]{1,10}";
	String ADDRESS_PATTERN = "[A-Za-z]{1,25}";
	String MOBILE_PATTERN = "[0-9]{10}";
	String EMAIL_PATTERN = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
	String LOAN_AMOUNT="[0-9]{1,8}";
	String LOAN_DURATION="[0-9]{1,2}";

	// creating methods for validates user Input
	boolean validateUserName(String userName);

	boolean validateAddress(String address);

	boolean validateMobile(String mobile);

	boolean validateEmail(String email);
	
	boolean validateLoanAmount(String amount);
	
	boolean validateLoanDuration(String duration);

	ArrayList<Customer> displayCustomers();
}
