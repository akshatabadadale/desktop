package com.capgemini.xyz.service;

import java.util.ArrayList;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanService {
	//convert interest rate percent/annum to month  
	double interestRate=9.5/(12*100);
	public void applyLoan(Loan loan);

	public double calculateEMI(double amount, int duration);

	ArrayList<Loan> displayLoan();
}
