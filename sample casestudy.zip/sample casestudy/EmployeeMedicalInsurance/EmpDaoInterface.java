package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Employee;

public interface EmpDaoInterface {
void storeToList(Employee emp);
Employee showDetails(int id);
}

