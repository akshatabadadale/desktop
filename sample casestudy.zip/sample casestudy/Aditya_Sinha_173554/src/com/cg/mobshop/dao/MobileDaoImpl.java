package com.cg.mobshop.dao;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.Util;

public class MobileDaoImpl implements MobileDao {
	private static Map<Integer, Mobiles> mobileEntries;

	Util util = new Util();

	@Override
	public List<Mobiles> getMobilleList() {
		for (Integer m : Util.getMobileEntries().keySet()) {
			List<Mobiles> mobiles = Arrays.asList(util.getMobileEntries()
					.get(m));
		}

		return (List<Mobiles>) util.getMobileEntries();
	}

	@Override
	public Mobiles deleteMobile(int mobcode) {
		return null;
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		switch (criteria) {
		case 1: {
			for (Integer m : Util.getMobileEntries().keySet()) {
				List<Mobiles> mobiles = Arrays.asList(util.getMobileEntries()
						.get(m));
			}

		}
		}
		return (List<Mobiles>) util.getMobileEntries();

	}
}
