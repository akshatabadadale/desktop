package com.cg.mobshop.service;

import java.util.Arrays;
import java.util.List;

import com.cg.mobshop.dao.MobileDao;
import com.cg.mobshop.dao.MobileDaoImpl;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl implements MobileService {

	MobileDao dao = new MobileDaoImpl();

	@Override
	public List<Mobiles> getMobilleList() {

		return dao.getMobilleList();
	}

	@Override
	public Mobiles deleteMobile(int mobcode) {
		return null;
	}

	@Override
	public List<Mobiles> SortList(int criteria) {
		return dao.SortList(criteria);
	}

}
