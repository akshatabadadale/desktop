
public class ShoppingCart {

	 Product [] cart;
	 int idx = 0;
 double total = 0;
		
	
	public void addProduct(Product product) {
	    cart[idx++] = product;
	    
	}
	
	public ShoppingCart() {
		
		cart = new Product[20];
	}

	public void checkout() {
		for(int ctr=0; ctr<idx; ctr++) {
		System.out.println("product: "+ cart[ctr].getName()+ " "+ "Price: "+ cart[ctr].getPrice());
		total = total +cart[ctr].getPrice();
		}
		System.out.println("Total: "+total);
	}
	
		
	
	
	

}
