public class Stock implements Exchange {
	public void viewQuote() {
		System.out.println("viewQuote is seen by holder, Broker and exchange");
	}

	public void getQuote() {
		System.out.println("getQuote is seen byt broker and exchnage");
	}

	public void setQuote() {
		System.out.println("setQuote is seen by only Exchange");
	}
}
