
public class TestSopping {
public static void main(String[] args) {
	ShoppingCart s1 = new ShoppingCart();
	s1.addProduct(new Product("bag", 500));
	s1.addProduct(new Product("shoe", 700));
	s1.addProduct(new Product("shirt", 1500));
	
	s1.checkout();
	

	
	
	
	
}
}
