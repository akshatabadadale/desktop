package com.capgemini.amazon.dao;

import java.util.ArrayList;

import com.capgemini.amazon.bean.Customer;
import com.capgemini.amazon.bean.Product;
import com.capgemini.amazon.exception.CustomerNotFound;

public class DaoClass implements DaoInterface{
   
	//customer database
	ArrayList<Customer> custDB= new ArrayList<Customer>();
	
	//cart database
	ArrayList<Cart> cartDB= new ArrayList<Cart>();
	
	//Product database
	ArrayList<Product> productDB= new ArrayList<Product>();
	
	@Override
	public Customer addCustomer(Customer customer) {
		custDB.add(customer);//add customer to database//try catch exception to be added
		return customer;
	}

	@Override
	public Product addProduct(Product product) {

		String temp= (Math.random()*100)+"";//RETURNDS DOUBLE OS CAST TO String by concatenation
		product.setProId(temp);
		productDB.add(product);
		return product; // returns product with id
	}

	@Override
	public Customer checkCust(String mobno, String password) throws CustomerNotFound{
		
		//Filter returns an array
		//findfirst returns the first vale from array
		// get to store in customer obj
		try {
			Customer cust = custDB.stream().filter(x->x.getMoblNo().equals(mobno) && x.getPassword().equals(password))
					.findFirst().get();
			return cust;
		} catch (Exception e) {
			throw new CustomerNotFound("No USer Found");
		}
		
	}

}
