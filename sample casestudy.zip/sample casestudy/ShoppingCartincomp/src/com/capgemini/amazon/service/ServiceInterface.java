package com.capgemini.amazon.service;

import com.capgemini.amazon.bean.Customer;
import com.capgemini.amazon.bean.Product;
import com.capgemini.amazon.exception.CustomerNotFound;

public interface ServiceInterface {
		
	public Customer addCustomer(Customer customer);//same methods as dao interface
	public Product addProduct(Product product);
	
	public Customer checkCust(String mobno, String password) throws CustomerNotFound	;
}
