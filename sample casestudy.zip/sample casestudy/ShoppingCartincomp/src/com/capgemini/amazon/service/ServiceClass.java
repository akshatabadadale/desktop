package com.capgemini.amazon.service;

import com.capgemini.amazon.bean.Customer;
import com.capgemini.amazon.bean.Product;
import com.capgemini.amazon.dao.DaoClass;
import com.capgemini.amazon.dao.DaoInterface;
import com.capgemini.amazon.exception.CustomerNotFound;

public class ServiceClass implements ServiceInterface {

	DaoInterface db= new DaoClass();//object to pass data to dao class
	
	
	@Override
	public Customer addCustomer(Customer customer) {

		return db.addCustomer(customer);//returns customer
	}

	@Override
	public Product addProduct(Product product) {
		return db.addProduct(product);//returns product
	}

	@Override
	public Customer checkCust(String mobno, String password) throws CustomerNotFound{
		try
		{
			return db.checkCust(mobno, password);
		}catch(CustomerNotFound e)
		{
			// get msg from dao class
			throw new CustomerNotFound(e.getMessage());
		}
	}

}
