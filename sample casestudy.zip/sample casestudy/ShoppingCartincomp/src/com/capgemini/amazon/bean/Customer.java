package com.capgemini.amazon.bean;

public class Customer {
	private String name;
	private String password;	
	private String emailId;
	private String moblNo;
	
	public Customer(){
		
	}
	
	public Customer(String name, String password, String emailId, String moblNo) {
		super();
		this.name = name;
		this.password = password;
		this.emailId = emailId;
		this.moblNo = moblNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMoblNo() {
		return moblNo;
	}
	public void setMoblNo(String moblNo) {
		this.moblNo = moblNo;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", password=" + password
				+ ", emailId=" + emailId + ", moblNo=" + moblNo + "]";
	}
	
	
}
