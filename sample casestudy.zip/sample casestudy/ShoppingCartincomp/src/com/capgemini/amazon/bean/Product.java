package com.capgemini.amazon.bean;

public class Product {
	private String proName;
	private String proId;
	private Double proCost;
	//private int proQty;

	
	public Product(String proName, Double proCost) {
		
		this.proName = proName;
		
		this.proCost = proCost;
		//this.proQty = proQty;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getProId() {
		return proId;
	}
	public void setProId(String proId) {
		this.proId = proId;
	}
	public Double getProCost() {
		return proCost;
	}
	public void setProCost(Double proCost) {
		this.proCost = proCost;
	}
	

	@Override
	public String toString() {
		return "Product [proName=" + proName + ", proId=" + proId
				+ ", proCost=" + proCost + " ]";
	}
	
}
