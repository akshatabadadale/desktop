package day3;

import day2.Employee;
/*
 * Employee is the parent class
 * it will have all attributes common to 
 * every employee
 * 
 * Mangaer is a child class
 * it willhave some additional attributes 
 * 
 * after extends keyword only one classname is
 * allowed 
 */
public class Manager extends Employee{
	
String perks="extra benefits";

//cannot reduce the visiblility 
//of the inherited method 
 public void display(){
	//super.display();//reusability seen
	System.out.println(perks);
}
Manager(){
//super(); //call the parent default constrcutor
//super("asdf");//calling pareameterized constrcutor
//of parent
	System.out.println("child object created ");
	
	
}
public Manager(int eid, String nm, String perks) {
	
	super(eid,nm);//reusability 
	this.perks=perks;
	
}








}
