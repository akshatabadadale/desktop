package day3;

public class UnderstandingStaticVariables {

	static int x;
	int y;
	public static void main(String[] args) {
		
		System.out.println(UnderstandingStaticVariables.x);
		
		//UnderstandingStaticVariables.y=10;wont work
		//object is needed 
	//	
	}
}
