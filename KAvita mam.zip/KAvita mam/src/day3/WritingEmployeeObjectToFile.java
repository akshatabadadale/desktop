package day3;

public class WritingEmployeeObjectToFile {
	
	public static void main(String[] args) {
		
		Employee emp =
				new Employee();
		
		//populate this object with values 
		//either via setter or constructor 
		//injection 
		
		
		//writeObject of ObjectOutputStream
		
		
		//output is that the entire emp obj
		//contents will be written to a file
		
		
		//the file contents wont be readable
		//to prove that the writing has been 
		//done correctly
		//read from the file and display on console
		
		//readObject //ObectInputStream
		
		
		
		
		
		
		
		
	}

}
