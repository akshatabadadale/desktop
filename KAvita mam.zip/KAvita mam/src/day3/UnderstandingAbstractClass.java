package day3;

//understanding abstract class
/*
 * it is a class whose object cannot be created
 *
 * can this class have properties ? yes
 * can this class have methods
 *  
 * but this class can have constructor: yes 
 * but when will these constructors get called
 * ans :when child object gets creaed 
 * how to work with abstract class  
 * ans : inheritance 
 * 
 * why is a class made abstract
 * ans : when the class contains atleast one abstract method  
 * 
 * can an abstract class not have single abstract method? 
 */
//class Reader 
abstract class Message{
	String from,to,subject,message;
	Message(){
		System.out.println("message ()");
	}
		
	abstract boolean sendMessage();	
	void tst(){
		//an abstract class can have regular methods also 
	}
	
}
class EmailMessage extends Message{

	@Override
	boolean sendMessage() {
		// TODO Auto-generated method stub
		return false;
	}
	
}
class FaxMessage extends Message{

	@Override
	boolean sendMessage() {
		// TODO Auto-generated method stub
		return false;
	}
	
}

public class UnderstandingAbstractClass {
	public static void main(String[] args) {
		
//Message msg= new Message();
		EmailMessage msg=  new EmailMessage();
		msg.from="asdf";
		
	}
}

abstract class A{
	
	//not necessary to have abstract methods 
}






