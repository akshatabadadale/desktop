package day3;

public class UnderstandingNullPointerException {
	String name;
	public static void main(String[] args) {
		String name="dfsd";
		UnderstandingNullPointerException
		obj = new UnderstandingNullPointerException();
		System.out.println(name.length());
		System.out.println(obj.name);
		System.out.println(obj.name.length());
		//will result in nullpointerexception 
		//System.out.println(this.name.length());
		
		//staic methods cannot use the this keyword
		
		
	}

}
