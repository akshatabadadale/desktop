package day3;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Scanner;



public class UsingScannerToReadFromFile {
	
	public static void main(String[] args) throws FileNotFoundException {
		
		FileInputStream fis=
				new FileInputStream("filename.txt");
		
		
		Scanner scan = new Scanner(fis);
		String line = scan.nextLine();
		System.out.println(line);
		//Scanner(InputStream source) 
		//add a while loop to print all lines
		
		
	}

}
