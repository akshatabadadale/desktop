package day3;

/*
 * method of the same signature is present
 * in parent and child class
 * signature means a combination of 
 * access specifier
 * return type
 * method name
 * paramter list
 * 
 * why shld v override ?
 * 
 * 
 */
public class UnderstandingOverriding {
	
	public static void main(String[] args) {
		
		
	}
	
	

}
