package day3;

public class ComparingMemoryAddress {
	
	public static void main(String[] args) {
		
		String s="hello";
		//System.out.println(s);
		String s1="hello";
				
		String s2=new String("hello");
		
		if(s==s2)//compares memory address
	System.out.println("both s and s2 are pointing to same object"
			+ " in memory");
		else
			System.out.println("s and s2 are different objects");
		
		if(s==s1)//compares memory address
			System.out.println("both s and s1 are pointing to same object"
					+ " in memory");
				
		
		if(s1.equals(s))//compares content 
			System.out.println("content in both object is same ");
		
		
	}

}
