package day3;

import day2.Employee;

public class UnderstandingInheritance {
	
	public static void main(String[] args) {
		
		System.out.println("testing constructors");
		Employee emp = new Employee(123,"empname");
		
		Manager mgr = new Manager(444,"mgr","driver with car");
		//mgr object has how many properties		?
		
		emp.display();
		
		mgr.display();
		//System.out.println();
		
		
	}

}
