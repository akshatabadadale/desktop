package day3;

import java.util.Scanner;

public class UsingScannerToReadFromString {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner("sdf;ajksdf;sdf");
		scan.next();
		//scan.useDelimiter(pattern)
		//try this out
		
	}
}
