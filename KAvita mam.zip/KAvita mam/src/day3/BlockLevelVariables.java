package day3;

public class BlockLevelVariables {
	
	public static void main(String[] args) {
		
	
	for(int i=0;i<10;i++)
		{System.out.println(i);
	//if curly braces are omitted, the first line
	//is assumed to be within the loop 
		System.out.println(i);
	}
}
}