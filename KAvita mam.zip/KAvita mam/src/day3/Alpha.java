package day3;

public class Alpha {
	public static void main(String[] args) {
		try {
			String x = args[0] + args[1];
		} catch (NullPointerException nullEx) {
			System.out.print("x");
		} catch (Exception ex) {
			System.out.print("y");
		} finally {
			System.out.print("z");
		}
	}
}
