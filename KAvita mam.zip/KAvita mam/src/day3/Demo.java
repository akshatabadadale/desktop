package day3;

public class Demo {
	 public static void main(String[] args) {
	  int x = 15;
	  int y = 0;
	  try {
	   int z = x / y;
	   return;
	  }catch(RuntimeException ex){
	   System.out.println("Runtime Exception");
	  }catch(Exception e){
	   System.out.println("Exception");
	  }
	  finally {
	   System.out.println("Finally");
	  }
	 }
	}