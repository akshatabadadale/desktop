package day3;

/*
 * accept 2 numbers from the command line adn 
 * add them up
 *  
 * java UnderstandingUncheckedExceptions
 * java UnderstandingUncheckedExceptions 10 
 * java UnderstandingUncheckedExceptions 10 20
 * java UnderstandingUncheckedExceptions abc uiuu asdfsd
 * java UnderstandingUncheckedExceptions 0 0 
 * java UnderstandingUncheckedExceptions 10 0
 * 
 * 
 */
public class UnderstandingUncheckedExceptions {
/*
 * 
 * command line arguments : String[] args
 * is involved in this situation 
 * another way of passing values to the java program
 * first method is scanner 	
 */
	public static void main(String[] args) {
		
		try{
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[0]+args[1]);
		//method of Integer class 
		//public static int parseInt(String s)
                //throws NumberFormatException
		int num1= Integer.parseInt(args[0]); 
		//"10" -->10
		int num2= Integer.parseInt(args[1]); 
		System.out.println(num1/num2);
		}catch(ArrayIndexOutOfBoundsException ae){
			System.out.println("enter atleast 2 numbers");
			
		}
		catch(NumberFormatException ff){
			
			System.out.println("enter only numbers not letters ");
		}
		catch(ArithmeticException ae){
			
			System.out.println("2 num cannot be 0");
		}
		
		
	}

}
