import java.util.Scanner;

/*
 * accept age and determine whether he 
 * is elible to vote or not
 * 
 * 
 * 
 */
public class IfElse {
	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter age ");
		int age = scan.nextInt();	
		if(age<18)
		{
			System.out.println("not eligible");
		}
		else
		{
				System.out.println("pls vote");
			
		}
	}

}
