import java.util.Scanner;

/*
 * if user name and password both r right
 * display welcome
 * if user name is wrong; display appro msg
 * if pwd is wrong displ appropriate msg
 * 
 */
public class NestedIf {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("enter user name");
	String username=scan.next();
	
	System.out.println("enter password");
	String password=scan.next();
	
	if(username.equalsIgnoreCase("capgemini")){
		
		if(password.equals("cg")){
			System.out.println("welcome");
		}
		else
		{
			System.out.println("wrong password");
		}
	}
	else
	{
		System.out.println("wrong username ");
	}
	
	
	
}
}
