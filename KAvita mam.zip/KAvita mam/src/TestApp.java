import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.*;


public class TestApp {

 public static void main(String[] args) {
  List<String> strList=
		  Arrays.asList("Java", "Scala", "C++", "Haskell", "Lisp");
  
  Stream stream = strList.stream();
  //obtaining a stream from the arraylist
  
Predicate<String> predicate=(value) -> value.length()> 4;
//creating a predicate acc to our requirement 

stream= stream.filter(predicate);
//passing the predicate to the filter method of the stream 
//return value is a stream which contains all values which meet the
//condition 

//if u want to print out each value int he stream use for each 
stream.forEach(val -> System.out.println(val));
//prints each value from the stream


//if u want to collect the stream values into a list use Collectors.toList();

List filtered =(List<String>)stream.collect(Collectors.toList());
 System.out.printf("filtered list : %s", filtered);
		      }
		      
		}

