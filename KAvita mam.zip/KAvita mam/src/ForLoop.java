import java.util.Scanner;

/*
 * ask teh user to enter his name and a number
 * display teh anme as many tiems as the num
 * 
 */
public class ForLoop {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("etner name");
		String name =scan.next();
		System.out.println("etner num ");
		int num=scan.nextInt();
		for(int ctr=1;ctr<=num;ctr++){
			System.out.println(ctr+ " : " + name);
		}
		
		
	}
}
