
public class MethodsOfStringClass {
	public static void main(String[] args) {
		String name="capgemini";
		
		Character ch=new Character('c');
		
		boolean b= Character.isLetter('a');
		
		ch.isLetter('c');
		
		
		
		System.out.println(name.length());
		char ch= name.charAt(0);
		System.out.println(ch);
		byte b[] = name.getBytes();
		System.out.println(b);
		//can array be printed directly 
		//address gets printed
		
		for(byte temp:b)
			System.out.println((char)temp);
		
		int pos = name.indexOf('i');
		//search 'i' in 'capgemini'
		System.out.println(pos);
		
		pos = name.lastIndexOf('i');
		System.out.println(pos);
		
		name="missisipi";
		System.out.println(name.indexOf('i'));
		System.out.println("=========");
		System.out.println(name.indexOf('i',3));
		//start from 3
		
		name.toLowerCase();
		name.toUpperCase();
		name.trim();
		name.substring(beginIndex, endIndex);
		name.
	}
}











