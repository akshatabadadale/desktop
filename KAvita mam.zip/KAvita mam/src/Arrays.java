/*
 * to store many values of same datatype
 */
public class Arrays {
	
	public static void main(String[] args) {
		
		int runs[]=new int[5];
		runs[0]=12;
		runs[1]=34;
		runs[2]=88;
		
		System.out.println(runs[1]);
		
		String names[]={"kohli","rohit"};
		
		for(int ctr=0;ctr<names.length;ctr++)
			System.out.println(names[ctr]);
		
		//the for each loop 
		for(String temp:names)
			System.out.println(temp);
		
		
	}

}
