import java.util.Scanner;


public class TillUserChoses {
public static void main(String[] args) {
	
	Scanner scan=new Scanner(System.in);
	String choice;
	do{
	System.out.println("enter user name");
	String username=scan.next();
	System.out.println("hello " + username);
	System.out.println("do u wish to continue y or n");
	 choice=scan.next();
	}while(choice.equals("y"));
	
}
	
}
