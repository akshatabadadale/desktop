package day1;

import java.util.Date;

import day2.Employee;

/*
 * pass values to the properties of the class
 * via constructor 
 * 
 */
public class ConstructorInjection {
	
	public static void main(String[] args) {
		
	Employee emp = new Employee
			("name",123456,'m',56565,false);
	//parameterized constructor
	
	System.out.println(emp);
	//the address of the obj gets printed 
	
	
	Date dt = new Date();
	System.out.println(dt);
		
	}

	
	
	
	
	
	
	
	
}
