import java.util.Date;
import java.util.Scanner;


public class UserInput {

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		//String temp = new String();
		//Date dt = new Date();
		System.out.println("Enter age ");
		int age = scan.nextInt();
		
		System.out.println("Etner name");
		String nm = scan.next();
		
		System.out.println("Enter height");
		float height = scan.nextFloat();
		
		System.out.println("name : " + nm );
		
		
		
	}
}
