
public class SwitchCase {

	public static void main(String[] args) {
		
		String dayOfWeek="wednesday";
		switch(dayOfWeek){
		
		case "monday":
			System.out.println("");
			break;
		case "tuesday" :
			
			break;
			
			default:
				System.out.println("");
		
		
		}
		
		
	}
}
