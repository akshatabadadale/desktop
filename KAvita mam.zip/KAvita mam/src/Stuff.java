import java.util.Comparator;


public class Stuff {
String name;
int value;
	
}


 class NameCompare implements Comparator<Stuff> {
 public int compare(Stuff a, Stuff b) {
 return b.name.compareTo(a.name);
 } 
 }
 
 class ValueCompare implements Comparator<Stuff> {
 public int compare(Stuff a, Stuff b) {
 return (a.value - b.value);
 } }
