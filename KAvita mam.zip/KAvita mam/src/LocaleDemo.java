import java.util.ResourceBundle;


public class LocaleDemo {
	public static void main(String[] args) {
		ResourceBundle bundle = ResourceBundle.getBundle("msgs");
		System.out.println(bundle.getString("greeting"));
	}
	

}
