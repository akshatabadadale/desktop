package day2;

public class Customer {

	String name;
	Customer(String name){
		this.name=name;
	}
	Customer(){
		
	}
	//if u provide a paramerised constructor
	//then the default constructor is not
	//available. u have to privide that also
	//explicitly 
	
	public static void main(String[] args) {
		
		Customer cust = new Customer();
	}
	
}
