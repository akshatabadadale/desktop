package day2;

public class WorkingWithUserDefinedMethods {
	
	
	int calculateSum(int num1,int num2){
		
		return num1+num2;
		
	}
	void displayMessage(){
		
		System.out.println("hello");
	}
	
	public static void main(String[] args) {
		
		WorkingWithUserDefinedMethods obj
		= new WorkingWithUserDefinedMethods();
		//int ans = obj.calculateSum(10,20);
		//System.out.println(ans);
		//obj.calculateSum(10,20,30);
		
		
		
		System.out.println(obj.calculateSum(10,20));
		
	//	System.out.println(obj.displayMessage());
		
		//cant call this method within println coz
		//it has a void return tyep 
		
		
		
		
		
		
	}

}
