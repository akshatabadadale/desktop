package day2;

import java.io.FileWriter;
import java.io.IOException;

/*
 * create a file thru the java program 
 * and write data in it
 * 
 */
public class WritingToFileThruCode {

	public static void main(String[] args) throws IOException {
		
		FileWriter writer=
				new FileWriter("filename.txt");
		//the above will create a file
		
		
		writer.write("abnc");
		
		writer.close();
		//unless file is closed;
		//data will not be written 
		
		
		
		
		
		
	}
}
