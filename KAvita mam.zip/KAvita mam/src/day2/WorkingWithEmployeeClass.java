package day2;

public class WorkingWithEmployeeClass {
	
	public static void main(String[] args) {
		
		Employee emp = new Employee();
		//constructor gets called on object creation 
	//	emp.empName="asdf";
		//eror coz empName is private 
		//can be accessed only with employee class
		
		
		System.out.println(emp.getEmpId());
		
		
		//setter injection 
		//to pass values to the properties of the class
		
		emp.setEmpName("laxmi");
		emp.setEmpId(123);
		emp.setGender('f');
		emp.setOnBench(true);
		emp.setSalary(1234345);
		
		
		/*System.out.println(emp.getEmpName());
		System.out.println(emp.getEmpId());
		System.out.println(emp.getGender());
		System.out.println(emp.getSalary());
		System.out.println(emp.isOnBench());*/
		
		
		System.out.println(emp);
		
		
		
		
		
		
	}

}
