package day2;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
public class AcceptFromUserAndWriteToFile {
	public static void main(String[] args) 
			throws IOException {
		Scanner scan = new Scanner(System.in);
		
		//PrintWriter(OutputStream out,boolean autoFlush) 
		
		//
		FileOutputStream fos=
				new FileOutputStream("filename.txt");
		
		PrintWriter writer=
				new PrintWriter(fos,true);
		String  choice;
		do{
		System.out.println("enter name");
		String name=scan.next();
		System.out.println("enter age");
		int age=scan.nextInt();
		writer.append(name + "" + age);
		
		System.out.println("do u wish to continue yes or no");
		choice=scan.next();
		}while(choice.equals("yes"));
		writer.close();
		
	}

}
