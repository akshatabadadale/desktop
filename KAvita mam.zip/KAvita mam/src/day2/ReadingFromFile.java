package day2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadingFromFile {
	
	public static void main(String[] args){
		String filename="filename.txt";
		try {
			FileReader reader=new FileReader(filename);
			while(true){
				int ch = reader.read();
						if(ch==-1)
							break;
			System.out.print((char)ch);
			}
			//System.out.println("welcome ");
		} catch (FileNotFoundException e) {
			System.out.println(filename+
					"  file not found ");
		e.printStackTrace();
			//useful for the devloper in debugging
			//finding out the line which caused the problem
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
