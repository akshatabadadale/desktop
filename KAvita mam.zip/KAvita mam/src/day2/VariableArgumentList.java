package day2;

public class VariableArgumentList {
	
	int calculateSum(int ... numbers){
		int total=0;
			for(int temp:numbers)
				total+=temp;
			
			return total;
		
	}
	
	public static void main(String[] args) {
		
		VariableArgumentList obj
		= new VariableArgumentList();
		
		System.out.println("2 numbers ..");
		System.out.println(obj.calculateSum(10,20));
		
		System.out.println("3 numbers ..");
		obj.calculateSum(10,20,30);
		
		
		//obj.calculateSum(10,20,30,40);
		//obj.calculateSum(10,20,30,40,50,60);
		
		obj.calculateSum();//0 or more
		
	}



}
