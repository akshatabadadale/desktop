package day2;

public class ReadingManyLettersAtATime {

	public static void main(String[] args) {
		
		public int read(char[] cbuf)
		
	}
}
