package day2;

public class UnderstandingMathClass {
	
	public static void main(String[] args) {
		//Math math = new Math();
		
		//constructor is not visible 
		System.out.println(Math.PI);
		System.out.println(Math.pow(2,16));
		
		
		
	}

}
